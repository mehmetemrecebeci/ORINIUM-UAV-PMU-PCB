*PADS-LIBRARY-PART-TYPES-V9*

WSLP40265L000FEA WSLP40265L000FEA I RES 7 1 0 0 0
TIMESTAMP 2026.05.22.19.49.11
"Mouser Part Number" 71-WSLP40265L000FEA
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Vishay-Dale/WSLP40265L000FEA?qs=OlC7AqGiEDksCRzHvj8RVw%3D%3D
"Manufacturer_Name" Vishay
"Manufacturer_Part_Number" WSLP40265L000FEA
"Description" 5 mOhms +/-1% 5W Chip Resistor Nonstandard Anti-Sulfur, Automotive AEC-Q200, Current Sense, Pulse Withstanding Metal Element, -65C ~ 170C
"Datasheet Link" https://www.vishay.com/docs/30180/wslp4026.pdf
"Geometry.Height" 2.99mm
GATE 1 4 0
WSLP40265L000FEA
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4

*END*
*REMARK* SamacSys ECAD Model
11599697/2066847/2.50/4/3/Resistor
