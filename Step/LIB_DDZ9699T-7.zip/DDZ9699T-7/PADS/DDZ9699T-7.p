*PADS-LIBRARY-PART-TYPES-V9*

DDZ9699T-7 SODFL1608X65N I DIO 7 1 0 0 0
TIMESTAMP 2026.05.22.19.54.31
"Mouser Part Number" 621-DDZ9699T-7
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Diodes-Incorporated/DDZ9699T-7?qs=mQbszxtPdlOBwg08InvD3Q%3D%3D
"Manufacturer_Name" Diodes Incorporated
"Manufacturer_Part_Number" DDZ9699T-7
"Description" Diodes Inc DDZ9699T-7 Zener Diode, 12V 5% 150 mW SMT 2-Pin SOD-523
"Datasheet Link" https://www.diodes.com//assets/Datasheets/ds30553.pdf
"Geometry.Height" 0.65mm
GATE 1 2 0
DDZ9699T-7
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
440922/2066847/2.50/2/2/Zener Diode
