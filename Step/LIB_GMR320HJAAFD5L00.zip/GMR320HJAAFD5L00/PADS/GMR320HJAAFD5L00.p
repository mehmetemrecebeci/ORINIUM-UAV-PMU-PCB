*PADS-LIBRARY-PART-TYPES-V9*

GMR320HJAAFD5L00 RESC7142X55N I RES 7 1 0 0 0
TIMESTAMP 2026.05.23.13.01.00
"Mouser Part Number" 755-GMR320HJAAFD5L00
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/ROHM-Semiconductor/GMR320HJAAFD5L00?qs=iLbezkQI%252Bsi1w%252BsvokprJQ%3D%3D
"Manufacturer_Name" ROHM Semiconductor
"Manufacturer_Part_Number" GMR320HJAAFD5L00
"Description" 7142 (2817) size, 10W, 5m, High Power Type Metal Plate Shunt Resistor (AEC-Q200 Qualified)
"Datasheet Link" https://fscdn.rohm.com/en/products/databook/datasheet/passive/resistor/chip_resistor/gmr-e.pdf
"Geometry.Height" 0.55mm
GATE 1 2 0
GMR320HJAAFD5L00
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
17551122/2066847/2.50/2/2/Resistor
