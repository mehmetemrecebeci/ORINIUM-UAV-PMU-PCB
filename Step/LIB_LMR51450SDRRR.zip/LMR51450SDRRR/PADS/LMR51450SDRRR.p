*PADS-LIBRARY-PART-TYPES-V9*

LMR51450SDRRR SON50P300X300X80-13N-D I ANA 7 1 0 0 0
TIMESTAMP 2026.05.22.22.36.56
"Mouser Part Number" 595-LMR51450SDRRR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/LMR51450SDRRR?qs=rQFj71Wb1eUvKinsjoLiUA%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" LMR51450SDRRR
"Description" Switching Voltage Regulators 36-V, 5-A synchronous buck converter
"Datasheet Link" https://www.ti.com/lit/ds/symlink/lmr51450.pdf?ts=1695888951673&ref_url=https%253A%252F%252Fwww.ti.com%252Fproduct%252FLMR51450%252Fpart-details%252FLMR51450SDRRR
"Geometry.Height" 0.8mm
GATE 1 13 0
LMR51450SDRRR
1 0 U SW_1
2 0 U SW_2
3 0 U SW_3
4 0 U BOOT
5 0 U PG
6 0 U RT
13 0 U PGND
12 0 U VIN_3
11 0 U VIN_2
10 0 U VIN_1
9 0 U EN
8 0 U AGND
7 0 U FB

*END*
*REMARK* SamacSys ECAD Model
17488053/2066847/2.50/13/3/Integrated Circuit
