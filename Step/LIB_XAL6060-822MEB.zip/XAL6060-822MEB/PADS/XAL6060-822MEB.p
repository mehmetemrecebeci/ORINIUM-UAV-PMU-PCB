*PADS-LIBRARY-PART-TYPES-V9*

XAL6060-822MEB XAL6060822MEB I IND 7 1 0 0 0
TIMESTAMP 2026.05.22.22.53.34
"Mouser Part Number" 994-XAL6060-822MEB
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Coilcraft/XAL6060-822MEB?qs=VJjuEbE9QBMp4bwCf2yUMQ%3D%3D
"Manufacturer_Name" COILCRAFT
"Manufacturer_Part_Number" XAL6060-822MEB
"Description" Fixed Inductors XAL6060 High Current 8.2 uH 20 % 8 A
"Datasheet Link" https://g.componentsearchengine.com/ga/XAL6060-822MEB
"Geometry.Height" 6.1mm
GATE 1 2 0
XAL6060-822MEB
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
363591/2066847/2.50/2/4/Inductor
