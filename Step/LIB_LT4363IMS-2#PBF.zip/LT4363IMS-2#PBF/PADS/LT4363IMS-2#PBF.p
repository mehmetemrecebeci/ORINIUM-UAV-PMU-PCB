*PADS-LIBRARY-PART-TYPES-V9*

LT4363IMS-2#PBF SOP65P490X110-12N I ANA 7 1 0 0 0
TIMESTAMP 2026.05.22.21.56.04
"Mouser Part Number" 584-LT4363IMS-2#PBF
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Analog-Devices/LT4363IMS-2PBF?qs=hVkxg5c3xu8ajQHTH9qgCg%3D%3D
"Manufacturer_Name" Analog Devices
"Manufacturer_Part_Number" LT4363IMS-2#PBF
"Description" High Voltage Surge Stopper with Current Limit
"Datasheet Link" https://www.analog.com/LT4363/datasheet
"Geometry.Height" 1.1mm
GATE 1 12 0
LT4363IMS-2#PBF
1 0 U FB
2 0 U OUT
3 0 U SNS
4 0 U GATE
5 0 U VCC
6 0 U \SHDN
12 0 U TMR
11 0 U ENOUT
10 0 U \FLT
9 0 U GND_2
8 0 U UV
7 0 U GND_1

*END*
*REMARK* SamacSys ECAD Model
262876/2066847/2.50/12/2/Integrated Circuit
