*PADS-LIBRARY-PART-TYPES-V9*

744311330 WE-HCI_7030/7040/705023 I IND 7 1 0 0 0
TIMESTAMP 2026.05.22.22.45.57
"Mouser Part Number" 710-744311330
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Wurth-Elektronik/744311330?qs=rS3zZhy2AQMeCoSMuoEKyw%3D%3D
"Manufacturer_Name" Wurth Elektronik
"Manufacturer_Part_Number" 744311330
"Description" WE-HCI SMT Flat Wire High Current Inductor Size 7040; L = 3.3 H +/-20%; IR = 6.5 A; Isat = 11 A; RDC = 17.2 m
"Datasheet Link" https://www.we-online.com/catalog/datasheet/744311330.pdf
"Geometry.Height" 4.8mm
GATE 1 2 0
744311330
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
573060/2066847/2.50/2/2/Inductor
