*PADS-LIBRARY-PART-TYPES-V9*

SF-3812F6000T-2 FUSC10131X330N I FUS 7 1 0 0 0
TIMESTAMP 2026.05.24.13.12.29
"Mouser Part Number" 652-SF-3812F6000T-2
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Bourns/SF-3812F6000T-2?qs=Cb2nCFKsA8pox2FPb0XXlQ%3D%3D
"Manufacturer_Name" Bourns
"Manufacturer_Part_Number" SF-3812F6000T-2
"Description" Surface Mount Fuses Singlfuse 3812 fast-acting 250V AC 60A
"Datasheet Link" https://www.mouser.be/datasheet/2/54/bourns_03202019_SF-3812F-T_datasheet-1544862.pdf
"Geometry.Height" 3.3mm
GATE 1 2 0
SF-3812F6000T-2
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
10983806/2066847/2.50/2/3/Fuse
